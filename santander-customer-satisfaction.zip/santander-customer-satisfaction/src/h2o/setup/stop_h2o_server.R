### All done, shutdown H2O  
h2o.shutdown(prompt=FALSE)